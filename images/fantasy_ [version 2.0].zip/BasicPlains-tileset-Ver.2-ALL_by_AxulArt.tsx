<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="BasicPlains-tileset-Ver.2-ALL_by_AxulArt" tilewidth="32" tileheight="32" tilecount="48" columns="12">
 <image source="BasicPlains-tileset-Ver.2-ALL_by_AxulArt.png" width="384" height="144"/>
</tileset>
